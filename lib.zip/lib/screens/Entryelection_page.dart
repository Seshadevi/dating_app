import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:dating/screens/logins/loginscreen.dart';

class SelectPage extends ConsumerWidget {
  const SelectPage({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: Column(
        children: [
          _buildImageSection(), // **Fixed Image Section**
          const Spacer(),
          _buildButtons(context), // **Buttons**
          const SizedBox(height: 20),
          _buildDisclaimerText(), // **Disclaimer**
          const SizedBox(height: 20),
        ],
      ),
    );
  }

  /// **Image Section Fixed**
  Widget _buildImageSection() {
    return Container(
      width: double.infinity,
      height: 450, // Adjusted for perfect fit
     
       decoration: const BoxDecoration(
          gradient: LinearGradient(
            // colors: [Color(0xFF00A878), Color(0xFF028090)],
            colors: [Color(0xFF869E23), Color(0xFF000000)],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
           borderRadius: BorderRadius.only(
          bottomLeft: Radius.circular(60), // **Rounded Bottom**
          bottomRight: Radius.circular(60),
        ),

        ),
      child: Center(
        child: ClipRRect(
          borderRadius: BorderRadius.circular(20),
          child: Image.asset(
            "assets/image.png", // **Your Image Path**
            width: 290, // Image Size Adjusted
            height: 290,
            fit: BoxFit.cover,
          ),
        ),
      ),
    );
  }

  /// **Buttons Section**
  Widget _buildButtons(BuildContext context) {
    return Column(
      children: [
        _longButton(
          "Continue With Google",
          Icons.account_circle,
          () {
            // Your Google Login Logic Here

            print("Google Login Clicked");
          },
        ),
        const SizedBox(height: 10),
        _longButton(
          "Continue With Facebook",
          Icons.facebook,
          () {
            // Your Facebook Login Logic Here
            print("Facebook Login Clicked");
          },
        ),
        const SizedBox(height: 10),
        _longButton(
          "Use Mobile Number",
          Icons.mobile_friendly,
          () {
             Navigator.push(
                            context,
                            MaterialPageRoute(builder: (context) =>  LoginScreen()),
                          );
            // Your Mobile Number Login Logic Here
            print("Mobile Login Clicked");
          },
        ),
      ],
    );
  }

  /// **Single Long Button**
  Widget _longButton(String text, IconData icon, VoidCallback onPressed) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 30),
      child: ElevatedButton.icon(
        onPressed: onPressed,
        style: ElevatedButton.styleFrom(
          backgroundColor: Colors.white,
          foregroundColor: Colors.black,
          minimumSize: const Size(double.infinity, 50), // Full width button
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(50),
            side: const BorderSide(
                color: Colors.grey, width: 1.5), // **Border**
          ),
        ),
        icon: Icon(icon, size: 30),
        label: Text(text, style: const TextStyle(fontSize: 14)),
      ),
    );
  }

  /// **Disclaimer Text**
  Widget _buildDisclaimerText() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 30),
      child: Text(
        "By Signing Up, You Agree To Our Terms. See How We Use Your Data In Our Privacy Policy.",
        textAlign: TextAlign.center,
        style: const TextStyle(
            fontSize: 15, color: Color.fromARGB(179, 29, 28, 28)),
      ),
    );
  }
}
